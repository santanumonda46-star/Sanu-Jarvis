package com.sanu.jarvis;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import okhttp3.*;
import org.json.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
 TextView chat,status; EditText input; Button send,mic; ScrollView scroll;
 SpeechRecognizer recognizer; TextToSpeech tts;
 final ArrayList<JSONObject> history=new ArrayList<>();
 // CHANGE THIS to your deployed HTTPS backend URL:
 static final String AI_URL="https://YOUR-BACKEND-DOMAIN/chat";

 @Override public void onCreate(Bundle b){
  super.onCreate(b); setContentView(R.layout.activity_main);
  chat=findViewById(R.id.chat); status=findViewById(R.id.status); input=findViewById(R.id.input);
  send=findViewById(R.id.send); mic=findViewById(R.id.mic); scroll=findViewById(R.id.scroll);
  tts=new TextToSpeech(this,r->{if(r==TextToSpeech.SUCCESS)tts.setLanguage(Locale.getDefault());});
  send.setOnClickListener(v->{String q=input.getText().toString().trim();if(!q.isEmpty()){input.setText("");handle(q);}});
  mic.setOnClickListener(v->listen());
  if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},42);
 }

 void listen(){
  if(!SpeechRecognizer.isRecognitionAvailable(this)){reply("Speech recognition is not available.");return;}
  if(recognizer!=null)recognizer.destroy(); recognizer=SpeechRecognizer.createSpeechRecognizer(this);
  recognizer.setRecognitionListener(new RecognitionListener(){
   public void onReadyForSpeech(Bundle b){status.setText("● LISTENING");}
   public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){}
   public void onEndOfSpeech(){status.setText("● THINKING");}
   public void onError(int e){status.setText("● ONLINE");}
   public void onResults(Bundle b){ArrayList<String> r=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(r!=null&&!r.isEmpty())handle(r.get(0));status.setText("● ONLINE");}
   public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
  });
  Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault()); recognizer.startListening(i);
 }

 void handle(String q){
  add("YOU: "+q); String s=q.toLowerCase(Locale.ROOT);
  if(s.contains("time")) reply("The current time is "+new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date())+".");
  else if(s.contains("date")||s.contains("today")) reply("Today is "+new SimpleDateFormat("EEEE, dd MMMM yyyy",Locale.getDefault()).format(new Date())+".");
  else if(s.contains("open youtube")){reply("Opening YouTube.");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com")));}
  else if(s.contains("weather")){reply("Opening weather information.");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q=weather+near+me")));}
  else if(s.startsWith("search ")){String x=q.substring(7).trim();reply("Searching for "+x+".");startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/search?q="+Uri.encode(x))));}
  else askAI(q);
 }

 void askAI(String q){
  if(AI_URL.contains("YOUR-BACKEND-DOMAIN")){reply("AI brain is ready, but the secure backend URL is not configured yet.");return;}
  status.setText("● AI THINKING");
  try{
   JSONArray msgs=new JSONArray();
   int start=Math.max(0,history.size()-12);
   for(int i=start;i<history.size();i++)msgs.put(history.get(i));
   JSONObject user=new JSONObject();user.put("role","user");user.put("content",q);msgs.put(user);
   JSONObject body=new JSONObject();body.put("messages",msgs);
   Request req=new Request.Builder().url(AI_URL).post(RequestBody.create(body.toString(),MediaType.parse("application/json"))).build();
   new OkHttpClient().newCall(req).enqueue(new Callback(){
    public void onFailure(Call c,java.io.IOException e){runOnUiThread(()->{status.setText("● ONLINE");reply("I could not reach my AI brain. Check the backend connection.");});}
    public void onResponse(Call c,Response r)throws java.io.IOException{
     String raw=r.body().string();
     runOnUiThread(()->{try{JSONObject o=new JSONObject(raw);String a=o.optString("answer","No answer.");historyAdd(q,a);status.setText("● ONLINE");reply(a);}catch(Exception e){status.setText("● ONLINE");reply("AI response could not be read.");}});
    }
   });
  }catch(Exception e){status.setText("● ONLINE");reply("AI request error.");}
 }

 void historyAdd(String q,String a){try{JSONObject u=new JSONObject();u.put("role","user");u.put("content",q);JSONObject x=new JSONObject();x.put("role","assistant");x.put("content",a);history.add(u);history.add(x);}catch(Exception ignored){}}
 void add(String x){chat.append(x+"\n\n");scroll.post(()->scroll.fullScroll(ScrollView.FOCUS_DOWN));}
 void reply(String x){add("JARVIS: "+x);if(tts!=null)tts.speak(x,TextToSpeech.QUEUE_FLUSH,null,"SANU");}
 @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
