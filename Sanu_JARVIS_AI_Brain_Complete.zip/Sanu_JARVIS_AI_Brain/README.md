# Sanu JARVIS — AI Brain Edition

This package contains:
1. Android voice assistant app
2. Node.js secure AI proxy backend

FLOW:
Android app -> your HTTPS backend -> AI provider -> Android app -> JARVIS voice

SECURITY:
Never put the AI provider secret key in the Android APK.
Set it as an environment variable on the backend.

BACKEND:
cd backend
npm install
Set:
AI_API_KEY=your_secret_key
AI_BASE_URL=https://your-provider.example/v1
AI_MODEL=your-model
PORT=3000
Then:
npm start

The backend expects an OpenAI-compatible chat-completions endpoint at:
POST {AI_BASE_URL}/chat/completions

For deployment use any HTTPS Node.js host. Put the deployed HTTPS URL into MainActivity.java:
private static final String AI_URL = "https://YOUR-BACKEND-DOMAIN/chat";

ANDROID:
Open the android folder as the Gradle Android project in your cloud Android builder.
Build the app module to produce the APK.

The app already has:
- microphone speech recognition
- text-to-speech
- chat UI
- AI requests
- time/date
- web search
- YouTube
- weather search
