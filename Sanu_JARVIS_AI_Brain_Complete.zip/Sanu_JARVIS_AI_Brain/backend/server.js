import http from "http";

const PORT = Number(process.env.PORT || 3000);
const KEY = process.env.AI_API_KEY;
const BASE = (process.env.AI_BASE_URL || "").replace(/\/$/, "");
const MODEL = process.env.AI_MODEL || "your-model";

function send(res, code, body){
  res.writeHead(code, {"Content-Type":"application/json","Access-Control-Allow-Origin":"*"});
  res.end(JSON.stringify(body));
}

const server=http.createServer(async (req,res)=>{
  if(req.method==="OPTIONS"){
    res.writeHead(204,{"Access-Control-Allow-Origin":"*","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"POST,OPTIONS"});
    return res.end();
  }
  if(req.method!=="POST" || req.url!=="/chat") return send(res,404,{error:"Not found"});
  if(!KEY || !BASE) return send(res,500,{error:"AI backend is not configured"});

  let raw="";
  req.on("data",c=>raw+=c);
  req.on("end",async()=>{
    try{
      const data=JSON.parse(raw);
      const messages=Array.isArray(data.messages)?data.messages:[];
      const r=await fetch(BASE+"/chat/completions",{
        method:"POST",
        headers:{"Content-Type":"application/json","Authorization":"Bearer "+KEY},
        body:JSON.stringify({
          model:MODEL,
          messages:[
            {role:"system",content:"You are Sanu JARVIS, a helpful, concise personal AI assistant. Reply naturally. If the user speaks Hindi/Hinglish, reply in the same style unless asked otherwise."},
            ...messages
          ],
          temperature:0.7
        })
      });
      const text=await r.text();
      if(!r.ok) return send(res,r.status,{error:"AI provider error",details:text.slice(0,1000)});
      const out=JSON.parse(text);
      const answer=out?.choices?.[0]?.message?.content || "I could not generate a response.";
      send(res,200,{answer});
    }catch(e){ send(res,500,{error:"Server error",details:String(e)}); }
  });
});
server.listen(PORT,()=>console.log("Sanu JARVIS AI backend listening on "+PORT));
